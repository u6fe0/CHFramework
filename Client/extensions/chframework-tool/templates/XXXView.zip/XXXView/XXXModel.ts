import { ModelBase } from '../../../../Runtime/Framework';
/**
 * 界面数据模型
 */
export class XXXModel extends ModelBase {
    constructor() {
        super();
    }
}


