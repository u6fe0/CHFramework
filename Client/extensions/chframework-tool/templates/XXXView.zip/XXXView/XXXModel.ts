import { ModelBase } from '../../../../CHFramework/Framework';
/**
 * 界面数据模型
 */
export class XXXModel extends ModelBase {
    constructor() {
        super();
    }
}


