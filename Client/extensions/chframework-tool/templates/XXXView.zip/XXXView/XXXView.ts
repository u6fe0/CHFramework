import { _decorator } from 'cc';
import { XXXViewModel } from './XXXViewModel';
const { ccclass, property } = _decorator;
import { ViewBase, BindViewModel } from '../../../../Runtime/Framework';

/**
 * 视图
 */

@ccclass('XXXView')
@BindViewModel(XXXViewModel)
export class XXXView extends ViewBase<XXXViewModel> {
    /**
     * 视图创建时调用
     */
    onCreate(): void {
    }
}
