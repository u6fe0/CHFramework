import { _decorator } from 'cc';
import { XXXViewModel } from './XXXViewModel';
const { ccclass, } = _decorator;
import { ViewBase, BindViewModel } from '../../../../CHFramework/Framework';

/**
 * 视图
 */

@ccclass('XXXView')
@BindViewModel(XXXViewModel)
export class XXXView extends ViewBase<XXXViewModel> {
    /**
     * 视图创建时调用
     */
    onCreate(): void {
    }
}
