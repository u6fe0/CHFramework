import { ViewModelBase, BindModel } from '../../../../Runtime/Framework';
import { XXXModel } from './XXXModel';

@BindModel(XXXModel)
export class XXXViewModel extends ViewModelBase<XXXModel> {
    constructor() {
        super();
    }
}


